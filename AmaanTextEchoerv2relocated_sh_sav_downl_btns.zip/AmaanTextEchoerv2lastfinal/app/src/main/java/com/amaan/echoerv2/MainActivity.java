package com.amaan.echoerv2;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.text.ClipboardManager;
import android.view.View;
import android.widget.*;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.widget.ScrollView;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {

    EditText inputText, repeatCount, lineGap;
    RadioGroup formatGroup;
    RadioButton rbUpper, rbLower, rbCapitalize;
    CheckBox addSerial, addNewLines;
    Button showOutput;
    ImageButton historyBtn, copyOutput, shareOutput, saveAsImage;
    TextView outputText;

    SharedPreferences prefs;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ask permission to write storage
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
			!= PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        // Bind views
        inputText = findViewById(R.id.inputText);
        repeatCount = findViewById(R.id.repeatCount);
        lineGap = findViewById(R.id.lineGap);

        formatGroup = findViewById(R.id.formatGroup);
        rbUpper = findViewById(R.id.rbUpper);
        rbLower = findViewById(R.id.rbLower);
        rbCapitalize = findViewById(R.id.rbCapitalize);

        addSerial = findViewById(R.id.addSerial);
        addNewLines = findViewById(R.id.addNewLines);

        showOutput = findViewById(R.id.showOutput);
        outputText = findViewById(R.id.outputText);

        historyBtn = findViewById(R.id.historyBtn);
        copyOutput = findViewById(R.id.copyOutput);
        shareOutput = findViewById(R.id.shareOutput);
        saveAsImage = findViewById(R.id.saveAsImage);

        prefs = getSharedPreferences("historyData", MODE_PRIVATE);
        editor = prefs.edit();

        // Show Output
        showOutput.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					generateOutput();
				}
			});

        // Copy/Share/Save handlers
        copyOutput.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					copyText();
				}
			});

		shareOutput.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					shareText();
				}
			});

		saveAsImage.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					saveImage();
				}
			});

		// History
			
		historyBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showHistoryDialog();
				}
			});

       
        }

    private void generateOutput() {
        String text = inputText.getText().toString();
        int count = 1;
        int gap = 0;

        try {
            count = Integer.parseInt(repeatCount.getText().toString());
        } catch (Exception ignored) {
        }

        try {
            gap = Integer.parseInt(lineGap.getText().toString());
        } catch (Exception ignored) {
        }

        boolean newline = addNewLines.isChecked();
        boolean serial = addSerial.isChecked();

        String format = "Normal";
        int selectedId = formatGroup.getCheckedRadioButtonId();
        if (selectedId == R.id.rbUpper) format = "UPPERCASE";
        else if (selectedId == R.id.rbLower) format = "lowercase";
        else if (selectedId == R.id.rbCapitalize) format = "Capitalize Each Word";

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) {
            String formatted = applyFormat(text, format);
            if (serial) {
                result.append(i + 1).append(". ");
            }
            result.append(formatted);

            if (newline) {
                result.append("\n");
                for (int g = 0; g < gap; g++) result.append("\n");
            } else {
                result.append(" ");
            }
        }

        String finalOutput = result.toString().trim();
        outputText.setText(finalOutput);

        // Save to rolling history (max 10)
        for (int i = 9; i >= 1; i--) {
            String prev = prefs.getString("history_" + i, null);
            if (prev != null) editor.putString("history_" + (i + 1), prev);
        }
        editor.putString("history_1", finalOutput);
        editor.apply();
    }

    private String applyFormat(String text, String format) {
        if (format.equals("UPPERCASE")) {
            return text.toUpperCase();
        } else if (format.equals("lowercase")) {
            return text.toLowerCase();
        } else if (format.equals("Capitalize Each Word")) {
            String[] words = text.toLowerCase().split(" ");
            StringBuilder result = new StringBuilder();
            for (String word : words) {
                if (!word.isEmpty()) {
                    result.append(Character.toUpperCase(word.charAt(0)))
						.append(word.substring(1))
						.append(" ");
                }
            }
            return result.toString().trim();
        } else {
            return text;
        }
    }

    private void copyText() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setText(outputText.getText().toString());
        Toast.makeText(this, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
    }

    private void shareText() {
        String output = outputText.getText().toString();
        if (output.isEmpty()) {
            Toast.makeText(this, "Nothing to share!", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, output);
        startActivity(Intent.createChooser(shareIntent, "Share output via"));
    }

    private void saveImage() {
        if (outputText.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "No output to save!", Toast.LENGTH_SHORT).show();
            return;
        }

        outputText.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(outputText.getWidth(), outputText.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        outputText.draw(canvas);

        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();

            File file = new File(dir, "output_" + System.currentTimeMillis() + ".png");
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();

            Toast.makeText(this, "Saved to Downloads ✅", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving image!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showHistoryDialog() {
        StringBuilder combinedHistory = new StringBuilder();
        for (int i = 1; i <= 10; i++) {
            String entry = prefs.getString("history_" + i, null);
            if (entry != null) {
                combinedHistory.append("🔹 ").append(entry).append("\n\n");
            }
        }

        if (combinedHistory.length() == 0) {
            combinedHistory.append("No history yet.");
        }

        TextView historyView = new TextView(this);
        historyView.setText(combinedHistory.toString());
        historyView.setPadding(20, 20, 20, 20);
        historyView.setVerticalScrollBarEnabled(true);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(historyView);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📜 History");
        builder.setView(scrollView);
        builder.setPositiveButton("OK", null);
        builder.setNegativeButton("Clear History", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					for (int i = 1; i <= 10; i++) {
						editor.remove("history_" + i);
					}
					editor.apply();
					Toast.makeText(MainActivity.this, "History cleared", Toast.LENGTH_SHORT).show();
				}
			});
        builder.show();
    }
}
